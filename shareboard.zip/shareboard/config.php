<?php

// Define DB Params
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "shareboard");

// Define URL
define("ROOT_PATH", "/shareboard/");
define("ROOT_URL", "http://localhost/shareboard/");