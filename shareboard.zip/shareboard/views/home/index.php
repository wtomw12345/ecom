<div class="text-center">
	<h1>Welcome To ShareBoard</h1>
	<p class="lead">Find something cool? Share it with our community. Look at other shares as well</p>
	<a class="btn btn-primary text-center" href="<?php echo ROOT_PATH;?>shares">Share Now</a>
</div>